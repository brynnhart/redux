'use strict';

/**
 * server/game/data/constants.js
 * All static game data ported directly from lord.js
 */

// ── Monster Stats — all 88 entries from lord.js lines 215–1000 ─────────────
const monster_stats = [
  { name:'Small Thief',                str:6,    gold:56,     weapon:'Small Dagger',            exp:2,     hp:9,    death:'You disembowel the little thieving menace!' },
  { name:'Rude Boy',                   str:3,    gold:7,      weapon:'Cudgel',                  exp:3,     hp:7,    death:'You quietly watch as the very Rude Boy bleeds to death.' },
  { name:'Old Man',                    str:5,    gold:73,     weapon:'Cane',                    exp:4,     hp:13,   death:'You finish him off, by tripping him with his own cane.' },
  { name:'Large Green Rat',            str:3,    gold:32,     weapon:'Sharp Teeth',             exp:1,     hp:4,    death:'A well placed step ends this small rodents life.' },
  { name:'Wild Boar',                  str:10,   gold:58,     weapon:'Sharp Tusks',             exp:5,     hp:9,    death:'You impale the boar between the eyes!' },
  { name:'Ugly Old Hag',               str:6,    gold:109,    weapon:'Garlic Breath',           exp:4,     hp:9,    death:'You emotionally crush the hag, by calling her ugly!' },
  { name:'Large Mosquito',             str:2,    gold:46,     weapon:'Blood Sucker',            exp:2,     hp:3,    death:'With a sharp slap, you end the Mosquitos life.' },
  { name:'Bran The Warrior',           str:12,   gold:234,    weapon:'Short Sword',             exp:10,    hp:15,   death:'After a hardy duel, Bran lies at your feet, dead.' },
  { name:'Evil Wretch',                str:7,    gold:76,     weapon:'Finger Nail',             exp:3,     hp:12,   death:'With a swift boot to her head, you kill her.' },
  { name:'Small Bear',                 str:9,    gold:154,    weapon:'Claws',                   exp:6,     hp:7,    death:'After a swift battle, you stand holding the Bears heart!' },
  { name:'Small Troll',                str:6,    gold:87,     weapon:'Uglyness',                exp:5,     hp:14,   death:'This battle reminds you how of how much you hate trolls.' },
  { name:'Green Python',               str:13,   gold:80,     weapon:'Dripping Fangs',          exp:6,     hp:17,   death:"You tie the mighty snake's carcass to a tree." },
  { name:'Gath The Barbarian',         str:12,   gold:134,    weapon:'Huge Spiked Club',        exp:9,     hp:13,   death:'You knock Gath down, ignoring his constant groaning.' },
  { name:'Evil Wood Nymph',            str:15,   gold:160,    weapon:'Flirtatios Behavior',     exp:11,    hp:10,   death:'You shudder to think of what would have happened, had you given in.' },
  { name:'Fedrick The Limping Baboon', str:8,    gold:97,     weapon:'Scary Faces',             exp:6,     hp:23,   death:'Fredrick will never grunt in anyones face again.' },
  { name:'Wild Man',                   str:13,   gold:134,    weapon:'Hands',                   exp:8,     hp:14,   death:'Pitting your wisdom against his brawn has won this battle.' },
  { name:'Brorandia The Viking',       str:21,   gold:330,    weapon:'Hugely Spiked Mace',      exp:20,    hp:18,   death:'You consider this a message to her people, "STAY AWAY!".' },
  { name:'Huge Bald Man',              str:19,   gold:311,    weapon:'Glare From Forehead',     exp:16,    hp:19,   death:"It wasn't even a close battle, you slaughtered him." },
  { name:'Senile Senior Citizen',      str:13,   gold:270,    weapon:'Crazy Ravings',           exp:13,    hp:11,   death:'You may have just knocked some sense into this old man.' },
  { name:'Membrain Man',               str:10,   gold:190,    weapon:'Strange Ooze',            exp:11,    hp:16,   death:'The monstrosity has been slain.' },
  { name:'Bent River Dryad',           str:12,   gold:150,    weapon:'Pouring Waterfall',       exp:9,     hp:16,   death:'You cannot resist thinking the Dryad is "All wet".' },
  { name:'Rock Man',                   str:8,    gold:300,    weapon:'Large Stones',            exp:12,    hp:27,   death:'You have shattered the Rock Mans head!' },
  { name:'Lazy Bum',                   str:19,   gold:380,    weapon:'Unwashed Body Odor',      exp:18,    hp:29,   death:'"This was a bum deal" You think to yourself.' },
  { name:'Two Headed Rotwieler',       str:18,   gold:384,    weapon:'Twin Barking',            exp:17,    hp:32,   death:'You have silenced the mutt, once and for all.' },
  { name:'Purple Monchichi',           str:14,   gold:763,    weapon:'Continous Whining',       exp:23,    hp:29,   death:'You cant help but realize you have just killed a real loser.' },
  { name:'Bone',                       str:27,   gold:432,    weapon:'Terrible Smoke Smell',    exp:16,    hp:11,   death:'Now that you have killed Bone, maybe he will get a life..' },
  { name:'Red Neck',                   str:19,   gold:563,    weapon:'Awfull Country Slang',    exp:19,    hp:16,   death:'The dismembered body causes a churning in your stomach.' },
  { name:'Winged Demon Of Death',      str:42,   gold:830,    weapon:'Red Glare',               exp:28,    hp:23,   death:'You cut off the Demons head, to be sure of its death.' },
  { name:'Black Owl',                  str:28,   gold:711,    weapon:'Hooked Beak',             exp:26,    hp:29,   death:'A well placed blow knocks the winged creature to the ground.' },
  { name:'Muscled Midget',             str:26,   gold:870,    weapon:'Low Punch',               exp:32,    hp:19,   death:'You laugh as the small man falls to the ground.' },
  { name:'Headbanger Of The West',     str:23,   gold:245,    weapon:'Ear Shattering Noises',   exp:43,    hp:27,   death:'You slay the rowdy noise maker and destroy his evil machines.' },
  { name:'Morbid Walker',              str:28,   gold:764,    weapon:'Endless Walking',         exp:9,     hp:10,   death:'Even lying dead on its back, it is still walking.' },
  { name:'Magical Evil Gnome',         str:24,   gold:638,    weapon:'Spell Of Fire',           exp:28,    hp:25,   death:"The Gnome's small body is covered in a deep red blood." },
  { name:'Death Dog',                  str:36,   gold:1150,   weapon:'Teeth',                   exp:36,    hp:52,   death:'You rejoice as the dog wimpers for the very last time.' },
  { name:'Weak Orc',                   str:27,   gold:900,    weapon:'Spiked Club',             exp:25,    hp:32,   death:'A solid blow removes the Orcs head!' },
  { name:'Dark Elf',                   str:43,   gold:1070,   weapon:'Small bow',               exp:33,    hp:57,   death:'The Elf falls at your feet, dead.' },
  { name:'Evil Hobbit',                str:35,   gold:1240,   weapon:'Smoking Pipe',            exp:46,    hp:95,   death:'The Hobbit will never bother anyone again!' },
  { name:'Short Goblin',               str:34,   gold:768,    weapon:'Short Sword',             exp:24,    hp:45,   death:'A quick lunge renders him dead!' },
  { name:'Huge Black Bear',            str:67,   gold:1765,   weapon:'Razor Claws',             exp:76,    hp:48,   death:'You bearly beat the Huge Bear...' },
  { name:'Rabid Wolf',                 str:45,   gold:1400,   weapon:'Deathlock Fangs',         exp:43,    hp:39,   death:'You pull the dogs lifeless body off you.' },
  { name:'Young Wizard',               str:64,   gold:1754,   weapon:'Weak Magic',              exp:64,    hp:35,   death:'This Wizard will never cast another spell!' },
  { name:'Mud Man',                    str:56,   gold:870,    weapon:'Mud Balls',               exp:43,    hp:65,   death:'You chop up the Mud Man into sushi!' },
  { name:'Death Jester',               str:34,   gold:1343,   weapon:'Horrible Jokes',          exp:32,    hp:46,   death:'You feel no pity for the Jester, his jokes being as bad as they were.' },
  { name:'Rock Man',                   str:87,   gold:1754,   weapon:'Large Stones',            exp:76,    hp:54,   death:'You have shattered the Rock Mans head!' },
  { name:'Pandion Knight',             str:64,   gold:3100,   weapon:'Orkos Broadsword',        exp:98,    hp:59,   death:'You are elated in the knowledge that you both fought honorably.' },
  { name:'Jabba',                      str:61,   gold:2384,   weapon:'Whiplashing Tail',        exp:137,   hp:198,  death:'The fat thing falls down, never to squirm again.' },
  { name:'Manoken Sloth',              str:54,   gold:2452,   weapon:'Dripping Paws',           exp:97,    hp:69,   death:'You have cut him down, spraying a neaby tree with blood.' },
  { name:'Trojan Warrior',             str:73,   gold:3432,   weapon:'Twin Swords',             exp:154,   hp:87,   death:'You watch, as the ants claim his body.' },
  { name:'Misfit The Ugly',            str:75,   gold:2563,   weapon:'Strange Ideas',           exp:120,   hp:89,   death:'You cut him cleanly down the middle, in a masterfull stroke.' },
  { name:'George Of The Jungle',       str:56,   gold:2230,   weapon:'Echoing Screams',         exp:128,   hp:43,   death:'You thought the story of George was a myth, until now.' },
  { name:'Silent Death',               str:113,  gold:4711,   weapon:'Pale Smoke',              exp:230,   hp:98,   death:'Instead of spilling blood, the creature seems filled with only air.' },
  { name:'Bald Medusa',                str:78,   gold:4000,   weapon:'Glare Of Stone',          exp:256,   hp:120,  death:"You are lucky you didnt look at her... Man was she ugly!" },
  { name:'Black Alligator',            str:65,   gold:3245,   weapon:'Extra Sharp Teeth',       exp:123,   hp:65,   death:'With a single stroke, you sever the creatures head right off.' },
  { name:'Clancy, Son Of Emporor Len', str:52,   gold:4764,   weapon:'Spiked Bull Whip',        exp:324,   hp:324,  death:"Its a pity so many new warriors get so proud." },
  { name:'Black Sorcerer',             str:86,   gold:2838,   weapon:'Spell Of Lightning',      exp:154,   hp:25,   death:"Thats the last spell this Sorcerer will ever cast!" },
  { name:'Iron Warrior',               str:100,  gold:6542,   weapon:'3 Iron',                  exp:364,   hp:253,  death:"You have bent the Iron warrior's Iron!" },
  { name:'Black Soul',                 str:112,  gold:5865,   weapon:'Black Candle',            exp:432,   hp:432,  death:'You have released the black soul.' },
  { name:'Gold Man',                   str:86,   gold:8964,   weapon:'Rock Arm',                exp:493,   hp:354,  death:'You kick the body of the Gold man to reveal some change..' },
  { name:'Screaming Zombie',           str:98,   gold:5322,   weapon:'Gaping Mouth Full Of Teeth', exp:354, hp:286, death:'The battle has rendered the zombie even more unattractive then he was.' },
  { name:'Satans Helper',              str:112,  gold:7543,   weapon:'Pack Of Lies',            exp:453,   hp:165,  death:"Apparently you have seen through the Devil's evil tricks" },
  { name:'Wild Stallion',              str:78,   gold:4643,   weapon:'Hoofs',                   exp:532,   hp:245,  death:"You only wish you could have spared the animal's life." },
  { name:'Belar',                      str:120,  gold:9432,   weapon:'Fists Of Rage',           exp:565,   hp:352,  death:'Not even Belar can stop you!' },
  { name:'Empty Armour',               str:67,   gold:6431,   weapon:'Cutting Wind',            exp:432,   hp:390,  death:'The whole battle leaves you with a strange chill.' },
  { name:'Raging Lion',                str:98,   gold:3643,   weapon:'Teeth And Claws',         exp:365,   hp:274,  death:'You rip the jaw bone off the magnificent animal!' },
  { name:'Huge Stone Warrior',         str:112,  gold:4942,   weapon:'Rock Fist',               exp:543,   hp:232,  death:'There is nothing left of the stone warrior, except a few pebbles.' },
  { name:'Magical Evil Gnome',         str:89,   gold:6384,   weapon:'Spell Of Fire',           exp:321,   hp:234,  death:"The Gnome's small body is covered in a deep, red blood." },
  { name:'Emporer Len',                str:210,  gold:12043,  weapon:'Lightning Bull Whip',     exp:764,   hp:432,  death:'His last words were.. "I have failed to avenge my son."' },
  { name:'Night Hawk',                 str:220,  gold:10433,  weapon:'Blood Red Talons',        exp:686,   hp:675,  death:'Your last swing pulls the bird out of the air, landing him at your feet.' },
  { name:'Charging Rhinoceros',        str:187,  gold:9853,   weapon:'Rather Large Horn',       exp:654,   hp:454,  death:'You finally felled the huge beast, but not without a few scratches.' },
  { name:'Goblin Pygmy',               str:165,  gold:13252,  weapon:'Death Squeeze',           exp:754,   hp:576,  death:"You laugh at the little Goblin's puny attack." },
  { name:'Goliath',                    str:243,  gold:14322,  weapon:'Six Fingered Fist',       exp:898,   hp:343,  death:'Now you know how David felt...' },
  { name:'Angry Liontaur',             str:187,  gold:13259,  weapon:'Arms And Teeth',          exp:753,   hp:495,  death:'You have laid this mythical beast to rest.' },
  { name:'Fallen Angel',               str:154,  gold:12339,  weapon:'Throwing Halos',          exp:483,   hp:654,  death:'You slay the Angel, then watch as it gets sucked down into the ground.' },
  { name:'Wicked Wombat',              str:198,  gold:13283,  weapon:"The Dark Wombats Curse",  exp:786,   hp:464,  death:"It's hard to believe a little wombat like that could be so much trouble." },
  { name:'Massive Dinosaur',           str:200,  gold:16753,  weapon:'Gaping Jaws',             exp:1204,  hp:986,  death:'The earth shakes as the huge beast falls to the ground.' },
  { name:'Swiss Butcher',              str:230,  gold:8363,   weapon:'Meat Cleaver',            exp:532,   hp:453,  death:"You're glad you won...You really didn't want the haircut.." },
  { name:'Death Gnome',                str:270,  gold:10000,  weapon:'Touch Of Death',          exp:654,   hp:232,  death:'You watch as the animals pick away at his flesh.' },
  { name:'Screeching Witch',           str:300,  gold:19753,  weapon:'Spell Of Ice',            exp:2283,  hp:674,  death:"You have silenced the witch's infernal screeching." },
  { name:'Rundorig',                   str:330,  gold:17853,  weapon:'Poison Claws',            exp:2748,  hp:675,  death:'Rundorig, once your friend, now lies dead before you.' },
  { name:'Wheeler',                    str:250,  gold:23433,  weapon:'Annoying Laugh',          exp:1980,  hp:786,  death:"You rip the wheeler's wheels clean off!" },
  { name:'Death Knight',               str:287,  gold:21923,  weapon:'Huge Silver Sword',       exp:4282,  hp:674,  death:'The Death knight finally falls, not only wounded, but dead.' },
  { name:'Werewolf',                   str:230,  gold:19474,  weapon:'Fangs',                   exp:3853,  hp:543,  death:"You have slaughtered the Werewolf. You didn't even need a silver bullet." },
  { name:'Fire Ork',                   str:267,  gold:24933,  weapon:'FireBall',                exp:3942,  hp:674,  death:"You have put out this Fire Ork's flame!" },
  { name:'Wans Beast',                 str:193,  gold:17141,  weapon:'Crushing Embrace',        exp:2432,  hp:1243, death:'The hairy thing has finally stopped moving.' },
  { name:'Lord Mathese',               str:245,  gold:24935,  weapon:'Fencing Sword',           exp:2422,  hp:875,  death:'You have wiped the sneer off his face once and for all.' },
  { name:'King Vidion',                str:400,  gold:28575,  weapon:'Long Sword Of Death',     exp:6764,  hp:1243, death:'You feel lucky to have lived. Things could have gone sour..' },
  { name:'Baby Dragon',                str:176,  gold:25863,  weapon:'Dragon Smoke',            exp:3675,  hp:2322, death:'This Baby Dragon will never grow up.' },
  { name:'Death Gnome',                str:356,  gold:31638,  weapon:'Touch Of Death',          exp:2300,  hp:870,  death:'You watch as the animals pick away at his flesh.' },
  { name:'Pink Elephant',              str:434,  gold:33844,  weapon:'Stomping',                exp:7843,  hp:1232, death:"You have witnessed the Pink Elephant...And you aren't even drunk!" },
  { name:"Gwendolens Nightmare",       str:490,  gold:35846,  weapon:'Dreams',                  exp:8232,  hp:764,  death:'This is the first Nightmare you have put to sleep.' },
  { name:'Flying Cobra',               str:400,  gold:37694,  weapon:'Poison Fangs',            exp:8433,  hp:1123, death:'The creature falls to the ground with a sickening thud.' },
  { name:"Rentakis Pet",               str:556,  gold:37584,  weapon:'Gaping Maw',              exp:9854,  hp:987,  death:"You vow to find Rentaki and tell him what you think about his new pet." },
  { name:'Ernest Brown',               str:432,  gold:34833,  weapon:'Knee',                    exp:9754,  hp:2488, death:'Ernest has finally learned his lesson, it seems.' },
  { name:'Scallian Rap',               str:601,  gold:22430,  weapon:'Way Of Hurting People',   exp:6784,  hp:788,  death:"Scallian's dead...Looks like you took out the trash..." },
  { name:'Apeman',                     str:498,  gold:38955,  weapon:'Hairy Hands',             exp:7202,  hp:1283, death:'The battle is over...Nothing is left but blood and hair.' },
];

// ── Armour Stats — from lord.js lines ~1397 ────────────────────────────────
const armour_stats = [
  { name:'Nothing!',         price:0,          num:0    },
  { name:'Coat',             price:200,         num:1    },
  { name:'Heavy Coat',       price:1000,        num:3    },
  { name:'Leather Vest',     price:3000,        num:10   },
  { name:'Bronze Armour',    price:10000,       num:15   },
  { name:'Iron Armour',      price:30000,       num:25   },
  { name:'Graphite Armour',  price:100000,      num:35   },
  { name:"Erdricks Armour",  price:150000,      num:50   },
  { name:'Armour Of Death',  price:200000,      num:75   },
  { name:"Able's Armour",    price:400000,      num:100  },
  { name:'Full Body Armour', price:1000000,     num:150  },
  { name:'Blood Armour',     price:4000000,     num:225  },
  { name:'Magic Protection', price:10000000,    num:300  },
  { name:"Belar's Mail",     price:40000000,    num:400  },
  { name:'Golden Armour',    price:100000000,   num:600  },
  { name:'Armour Of Lore',   price:400000000,   num:1000 },
];

// ── Weapon Stats — from lord.js lines ~1416 ────────────────────────────────
const weapon_stats = [
  { name:'Fists',          price:0,          num:0   },
  { name:'Stick',          price:200,         num:5   },
  { name:'Dagger',         price:1000,        num:10  },
  { name:'Short Sword',    price:3000,        num:20  },
  { name:'Long Sword',     price:10000,       num:30  },
  { name:'Huge Axe',       price:30000,       num:40  },
  { name:'Bone Cruncher',  price:100000,      num:60  },
  { name:'Twin Swords',    price:150000,      num:80  },
  { name:'Power Axe',      price:200000,      num:120 },
  { name:"Able's Sword",   price:400000,      num:180 },
  { name:"Wan's Weapon",   price:1000000,     num:250 },
  { name:'Spear of Gold',  price:4000000,     num:350 },
  { name:'Crystal Shard',  price:10000000,    num:500 },
  { name:"Nira's Teeth",   price:40000000,    num:800 },
  { name:'Blood Sword',    price:100000000,   num:1200},
  { name:'Death Sword',    price:400000000,   num:2000},
];

// ── Trainer Stats ──────────────────────────────────────────────────────────
const trainer_stats = [
  {}, // index 0 unused
  { is_arena:true, name:'Halder',        weapon:'Short Sword',          swear:"Belar!!! You are truly a great warrior!",              needstr1:"Gee, your muscles are getting bigger than mine...", needstr2:'',               death:'  You blew your master away!', str:15,   hp:30,   hp_gained:10,  str_gained:5,   def:2,   need:100      },
  { is_arena:true, name:'Barak',         weapon:'Battle Axe',           swear:"Children of Mara!!! You have bested me??!",            needstr1:"You know, you are actually getting pretty good with", needstr2:"that thing...\"", death:'  You blew your master away!', str:17,   hp:40,   hp_gained:15,  str_gained:7,   def:3,   need:400      },
  { is_arena:true, name:'Aragorn',       weapon:'Twin Swords',          swear:"Torak's Eye!!! You are a great warrior!",              needstr1:'You have learned everything I can teach you.',      needstr2:'',               death:'  You blew your master away!', str:35,   hp:70,   hp_gained:20,  str_gained:10,  def:5,   need:1000     },
  { is_arena:true, name:'Olodrin',       weapon:'Power Axe',            swear:'Ye Gods!! You are a master warrior!',                  needstr1:'You are becoming a very skilled warrior.',          needstr2:'',               death:'  You blew your master away!', str:70,   hp:120,  hp_gained:30,  str_gained:12,  def:10,  need:4000     },
  { is_arena:true, name:'Sandtiger',     weapon:'Blessed Sword',        swear:'Very impressive...Very VERY impressive.',              needstr1:'Gee - You really know how to handle your shaft!',   needstr2:'',               death:'  You blew your master away!', str:100,  hp:200,  hp_gained:50,  str_gained:20,  def:15,  need:10000    },
  { is_arena:true, name:'Sparhawk',      weapon:'Double Bladed Sword',  swear:'This Battle is yours...You have fought with honor.',   needstr1:"You're getting the hang of it now!",               needstr2:'',               death:'  You blew your master away!', str:150,  hp:400,  hp_gained:75,  str_gained:35,  def:22,  need:40000    },
  { is_arena:true, name:'Atsuko Sensei', weapon:'Huge Curved Blade',    swear:'Even though you beat me, I am proud of you.',         needstr1:'You are ready to be tested on the battle field!',   needstr2:'',               death:'  You blew your master away!', str:250,  hp:600,  hp_gained:125, str_gained:50,  def:35,  need:100000   },
  { is_arena:true, name:'Aladdin',       weapon:'Shiny Lamp',           swear:"I don't need a genie to see that you beat me, man!",  needstr1:'You REALLY know how to use your &PWE!!!',           needstr2:'',               death:'  You blew your master away!', str:350,  hp:800,  hp_gained:185, str_gained:75,  def:60,  need:400000   },
  { is_arena:true, name:'Prince Caspian',weapon:'Flashing Rapier',      swear:'Good show, chap! Jolly good show!',                   needstr1:'Something tells me that you are as good as I am now.', needstr2:'',             death:'  You blew your master away!', str:500,  hp:1200, hp_gained:250, str_gained:110, def:80,  need:1000000  },
  { is_arena:true, name:'Gandalf',       weapon:'Huge Fireballs',       swear:"Torak's Tooth! You are great!",                       needstr1:'You are becoming a very skilled warrior',            needstr2:'',               death:'  You blew your master away!', str:800,  hp:1800, hp_gained:350, str_gained:150, def:120, need:4000000  },
];

// ── Castle names ───────────────────────────────────────────────────────────
const castles = [
  '', // index 0 unused
  'Castle Coldrake',
  'Fortress Liddux',
  'Gannon Keep',
  'Penyon Manor',
  "Dema's Lair",
];

// ── Level-up experience thresholds ────────────────────────────────────────
// Ported from lord.js level checking logic
const level_exp = [
  0,        // level 1
  200,      // level 2
  1000,     // level 3
  2500,     // level 4
  5000,     // level 5
  9000,     // level 6
  18000,    // level 7
  35000,    // level 8
  75000,    // level 9
  150000,   // level 10
  300000,   // level 11
  750000,   // level 12 — max
];

const DEFAULT_SETTINGS = {
  forest_fights    : 15,
  pvp_fights       : 1,
  interest_rate    : 10,
  max_players      : parseInt(process.env.MAX_PLAYERS, 10) || 150,
};

module.exports = {
  monster_stats,
  armour_stats,
  weapon_stats,
  trainer_stats,
  castles,
  level_exp,
  DEFAULT_SETTINGS,
};
